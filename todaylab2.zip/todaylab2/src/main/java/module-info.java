module com.example.todaylab2 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.todaylab2 to javafx.fxml;
    exports com.example.todaylab2;
}